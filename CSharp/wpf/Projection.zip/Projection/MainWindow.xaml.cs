﻿using System.Windows;
using System.Windows.Controls;

namespace Projection
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        double ToMeters(double value, string unit)
        {
            return unit switch
            {
                "metr" => value,
                "kilometr" => value * 1000,
                "centymetr" => value / 100,
                "cal" => value * 0.0254,
                "stopa" => value * 0.3048,
                "mila" => value * 1609.34,
                _ => 0
            };
        }

        double FromMeters(double meters, string unit)
        {
            return unit switch
            {
                "metr" => meters,
                "kilometr" => meters / 1000,
                "centymetr" => meters * 100,
                "cal" => meters / 0.0254,
                "stopa" => meters / 0.3048,
                "mila" => meters / 1609.34,
                _ => 0
            };
        }


        double ToKg(double value, string unit)
        {
            return unit switch
            {
                "kilogram" => value,
                "gram" => value / 1000,
                "funt" => value * 0.453592,
                "ton" => value * 1000,
                _ => 0
            };
        }

        double FromKg(double kg, string unit)
        {
            return unit switch
            {
                "kilogram" => kg,
                "gram" => kg * 1000,
                "funt" => kg / 0.453592,
                "tona" => kg / 1000,
                _ => 0
            };
        }


        double ToCelsius(double value, string unit)
        {
            return unit switch
            {
                "Celsjusz" => value,
                "Fahrenheit" => (value - 32) * 5 / 9,
                "Kelwin" => value - 273.15,
                _ => 0
            };
        }

        double FromCelsius(double c, string unit)
        {
            return unit switch
            {
                "Celsjusz" => c,
                "Fahrenheit" => c * 9 / 5 + 32,
                "Kelwin" => c + 273.15,
                _ => 0
            };
        }

        private void AddHistory(ListBox historyList, string text)
        {
            if (historyList.Items.Count >= 5)
                historyList.Items.RemoveAt(4);
            historyList.Items.Insert(0,text);
        }


        private void Convert_Click(object sender, RoutedEventArgs e)
        {
            int index = MainTabs.SelectedIndex;

            switch (index)
            {
                case 0:
                    if (FromLength.SelectedItem == null || ToLength.SelectedItem == null)
                    {
                        MessageBox.Show("Wybierz jednostki źródłowe i docelowe!");
                        return;
                    }

                    if (!double.TryParse(InputLength.Text, out double inputL) || inputL <= 0)
                    {
                        MessageBox.Show("Wprowadź poprawną dodatnią liczbę dla długości!");
                        return;
                    }
                    

                    string fromL = ((ComboBoxItem)FromLength.SelectedItem).Content.ToString();
                    string toL = ((ComboBoxItem)ToLength.SelectedItem).Content.ToString();
                    double meters = ToMeters(inputL, fromL);
                    double resultL = FromMeters(meters, toL);
                    OutputLength.Content = resultL.ToString("0.######");
                    AddHistory(HistoryLength, $"{inputL} {fromL} → {resultL:0.######} {toL}");
                    break;

                case 1:
                    if (FromMass.SelectedItem == null || ToMass.SelectedItem == null)
                    {
                        MessageBox.Show("Wybierz jednostki źródłowe i docelowe!");
                        return;
                    }

                    if (!double.TryParse(InputMass.Text, out double inputM) || inputM <= 0)
                    {
                        MessageBox.Show("Wprowadź poprawną dodatnią liczbę dla masy!");
                        return;
                    }
                    
                    string fromM = ((ComboBoxItem)FromMass.SelectedItem).Content.ToString();
                    string toM = ((ComboBoxItem)ToMass.SelectedItem).Content.ToString();
                    double kg = ToKg(inputM, fromM);
                    double resultM = FromKg(kg, toM);
                    OutputMass.Content = resultM.ToString("0.######");
                    AddHistory(HistoryMass, $"{inputM} {fromM} → {resultM:0.######} {toM}");
                    break;

                case 2: 
                    if (!double.TryParse(InputTemp.Text, out double inputT))
                    {
                        MessageBox.Show("Wprowadź poprawną liczbę dla temperatury!");
                        return;
                    }
                    if (FromTemp.SelectedItem == null || ToTemp.SelectedItem == null)
                    {
                        MessageBox.Show("Wybierz jednostki źródłowe i docelowe!");
                        return;
                    }

                    string fromT = ((ComboBoxItem)FromTemp.SelectedItem).Content.ToString();
                    string toT = ((ComboBoxItem)ToTemp.SelectedItem).Content.ToString();
                    double c = ToCelsius(inputT, fromT);
                    double resultT = FromCelsius(c, toT);
                    OutputTemp.Content = resultT.ToString("0.######");
                    AddHistory(HistoryTemp, $"{inputT} {fromT} → {resultT:0.######} {toT}");
                    break;
            }
        }



        private void Clear_Click(object sender, RoutedEventArgs e)
        {
            int index = MainTabs.SelectedIndex;

            switch (index)
            {
                case 0:
                    InputLength.Text = "0";
                    OutputLength.Content = "0";
                    HistoryLength.Items.Clear();
                    break;
                case 1:
                    InputMass.Text = "0";
                    OutputMass.Content = "0";
                    HistoryMass.Items.Clear();
                    break;
                case 2:
                    InputTemp.Text = "0";
                    OutputTemp.Content = "0";
                    HistoryTemp.Items.Clear();
                    break;
            }
        }
    }
}
